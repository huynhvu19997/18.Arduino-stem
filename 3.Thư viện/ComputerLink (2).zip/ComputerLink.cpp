#include "ComputerLink.h"

ComputerLink::ComputerLink(HardwareSerial& serial, uint8_t deviceID)
    : _serial(serial), _deviceID(deviceID) {}

bool ComputerLink::readRegisters(uint16_t address, uint8_t numOfPoints, uint16_t* buffer) {
    comlink_t telegram = { numOfPoints, address, 0x03 };
    sendRequest(telegram);
    return receiveResponse(buffer, numOfPoints);
}

bool ComputerLink::writeRegister(uint16_t address, uint16_t value) {
    comlink_t telegram = { 1, address, 0x06 };
    sendRequest(telegram);
    return true;
}

void ComputerLink::sendRequest(comlink_t& telegram) {
    _serial.write(_deviceID);
    _serial.write(telegram.functionCode);
    _serial.write(telegram.address >> 8);
    _serial.write(telegram.address & 0xFF);
    _serial.write(0x00);
    _serial.write(telegram.numOfPoints);
}

bool ComputerLink::receiveResponse(uint16_t* buffer, uint8_t numOfPoints) {
    uint32_t timeout = millis() + 100;
    while (_serial.available() < numOfPoints * 2) {
        if (millis() > timeout) return false;
    }

    for (uint8_t i = 0; i < numOfPoints; i++) {
        uint8_t high = _serial.read();
        uint8_t low = _serial.read();
        buffer[i] = (high << 8) | low;
    }
    return true;
}
