#ifndef COMPUTERLINK_H
#define COMPUTERLINK_H

#include <Arduino.h>

typedef struct {
    uint8_t numOfPoints;
    uint16_t address;
    uint8_t functionCode;
} comlink_t;

class ComputerLink {
public:
    ComputerLink(HardwareSerial& serial, uint8_t deviceID);

    bool readRegisters(uint16_t address, uint8_t numOfPoints, uint16_t* buffer);
    bool writeRegister(uint16_t address, uint16_t value);

private:
    HardwareSerial& _serial;
    uint8_t _deviceID;

    void sendRequest(comlink_t& telegram);
    bool receiveResponse(uint16_t* buffer, uint8_t numOfPoints);
};

#endif
