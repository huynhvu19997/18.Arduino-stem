#include <Arduino.h>
#include <SoftwareSerial.h>

#ifndef E32_433T30D_10408_H
#define E32_433T30D_10408_H

class E32_433T30D_10408
{
    private:
        int _M0;
        int _M1;
        int _pinS1;
        int _pinS2;
        SoftwareSerial* softSerial;
        
    public:
        E32_433T30D_10408( int M0, int M1, int pinS1, int pinS2);
        void begin();
        float GetData();
        void SetData(const char* DataSend);
};

#endif