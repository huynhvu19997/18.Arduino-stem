#include <Arduino.h>
//#include <SoftwareSerial.h>
#include "E32_433T30D_10408.h"

E32_433T30D_10408* instance = NULL;
E32_433T30D_10408::E32_433T30D_10408(int M0, int M1, int pinS1, int pinS2):
_M0(M0), _M1(M1), _pinS1(pinS1),_pinS2(pinS2)
{ 
    instance = this;
    softSerial = new SoftwareSerial(_pinS1,_pinS2);
}

void E32_433T30D_10408::begin()
{
    //SoftwareSerial mySerial(_pinS1,_pinS2);
    softSerial->begin(115200);
    pinMode(_M0,OUTPUT);
    pinMode(_M1,OUTPUT);
    digitalWrite(_M0,LOW);
    digitalWrite(_M1,LOW);
    
}

float E32_433T30D_10408::GetData()
{
    if (softSerial->available())
    {
        String DataGet= softSerial->readStringUntil('\n');
        return DataGet.toFloat();
    }
}

void E32_433T30D_10408::SetData(const char* DataSend)
{
    softSerial ->println(DataSend);
}