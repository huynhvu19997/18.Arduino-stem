#include "Led_Inter.h"
#include <Arduino.h>

/// @brief 
volatile bool _ledState = false;
Led_Inter* instance = NULL;

Led_Inter::Led_Inter(int buttonPin, int ledPin):
_buttonpin(buttonPin),_ledpin(ledPin)
{
    instance= this;
}

void Led_Inter::begin()
{
    pinMode(_buttonpin, INPUT_PULLUP);
    pinMode(_ledpin, OUTPUT);
    digitalWrite(_ledpin, LOW);
    attachInterrupt(digitalPinToInterrupt(_buttonpin), handleInterrupt, FALLING);
}

void Led_Inter::handleInterrupt()
{
    if (instance)
    {
        instance ->_ledState = !instance ->_ledState;
        digitalWrite(instance->_ledpin, instance->_ledState?HIGH:LOW);
    }
    
}