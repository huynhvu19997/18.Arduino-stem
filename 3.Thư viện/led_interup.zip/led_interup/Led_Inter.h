#include <Arduino.h>

#ifndef LED_INTER_H
#define LED_INTER_H

    class Led_Inter
    {
        private:
            int _buttonpin;
            int _ledpin;
            volatile bool _ledState;
            static void handleInterrupt();

        public:
            
            Led_Inter(int buttonpin, int ledPin);
            void begin();
    };
    
#endif