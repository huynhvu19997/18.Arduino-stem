#include <Arduino.h>
#include "Segment_7.h"

Segment_7:: Segment_7(int lacthpin, int clockpin, int datapin):
    _latchpin(lacthpin), _clockpin(clockpin),_datapin(datapin),
    _Led([10]={215,132,203,206,156,94,95,196,223,222}),  _Count(0),
{}

Segment_7::LED_Show(int _Count)
{
    shiftOut(_datapin,_latchpin,LSBFIRST, _Led[(int)(_Count % 10)]);
    shiftOut(_datapin,_latchpin,LSBFIRST, _Led[(int)(_Count / 10) % 10]);
    shiftOut(_datapin,_latchpin,LSBFIRST, _Led[(int)(_Count / 100) % 100]);
    shiftOut(_datapin,_latchpin,LSBFIRST, _Led[(int)(_Count / 1000)% 1000]);
    digitalWrite(_latchpin, HIGH);
    digitalWrite(_latchpin,LOW);
    millis();
}