#include <Arduino.h>
#ifndef SEGMENT_7_H
#define SEGMENT_7_H

class Segment_7
{
    private:
        int _latchpin;
        int _clockpin;
        int _datapin;
        int _Led[10]= {215,132,203,206,156,94,95,196,223,222};
        int _Count;

    public:
        Segment_7(int latchpin, int clockpin, int datapin);
        void LED_Show(int Count);
};

#endif