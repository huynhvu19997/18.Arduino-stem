#include <Arduino.h>
#ifndef E6B2_CWZ6C_H
#define E6B2_CWZ6C_H

class E6B2_CWZ6C
{
    private:
        byte _pinA;
        byte _pinB;
        int _so_xung_data;
        float _chu_vi_banh_rang;
        volatile float _xung;
        float _temp;


        void _updateCount();
        static void _demxung();

    public:
        E6B2_CWZ6C(byte pinA, byte pinB, int so_xung_data, float chu_vi_banh_rang);
        void begin();
        float getlength();
        void reset();
};


#endif