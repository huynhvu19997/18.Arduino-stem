#include <Arduino.h>
#include "E6B2_CWZ6C.h"

E6B2_CWZ6C* instance = NULL;

E6B2_CWZ6C::E6B2_CWZ6C(byte pinA, byte pinB, int so_xung_data, float chu_vi_banh_rang):
    _pinA(pinA), _pinB(pinB), _so_xung_data(so_xung_data), 
    _chu_vi_banh_rang(chu_vi_banh_rang),_xung(0), _temp(0)
    {
        instance = this;
    }

void E6B2_CWZ6C::begin()
{
    pinMode(_pinA, INPUT_PULLUP);
    pinMode(_pinB, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(_pinA), _demxung,RISING);
}

float E6B2_CWZ6C::getlength()
{
    if (_xung != _temp)
    {
        _temp = _xung;
        float chieu_dai = (_temp/_so_xung_data)*_chu_vi_banh_rang;
        return chieu_dai;
    }
}

void E6B2_CWZ6C::reset()
{
    _xung=0;
}



void E6B2_CWZ6C::_updateCount()
{
    bool stateA = digitalRead(_pinB);
    if (stateA)
    {
        _xung++;
        millis();
    }
    else
    {
        _xung--;
        millis();
    }
    
}

void E6B2_CWZ6C::_demxung()
{
    if (instance)
    {
        instance->_updateCount();
    }
    
}