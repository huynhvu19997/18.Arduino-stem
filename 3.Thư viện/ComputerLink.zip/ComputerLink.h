#ifndef COMPUTERLINK_H
#define COMPUTERLINK_H

#include <Arduino.h>

class ComputerLink {
public:
    ComputerLink(Stream& serial, byte deviceAddress);
    void begin();
    int readD(int address);
    void writeD(int address, int value);

private:
    Stream& _serial;
    byte _deviceAddress;

    void sendCommand(const String& command);
    String receiveResponse();
    String buildReadCommand(int address);
    String buildWriteCommand(int address, int value);
};

#endif
