#include "ComputerLink.h"

ComputerLink::ComputerLink(Stream& serial, byte deviceAddress)
    : _serial(serial), _deviceAddress(deviceAddress) {}

void ComputerLink::begin() {
    // Initialization if needed
}

int ComputerLink::readD(int address) {
    String command = buildReadCommand(address);
    sendCommand(command);
    String response = receiveResponse();
    return response.toInt(); // Simplified parsing
}

void ComputerLink::writeD(int address, int value) {
    String command = buildWriteCommand(address, value);
    sendCommand(command);
}

void ComputerLink::sendCommand(const String& command) {
    _serial.print(command);
}

String ComputerLink::receiveResponse() {
    String response = "";
    unsigned long start = millis();
    while (millis() - start < 1000) {
        if (_serial.available()) {
            char c = _serial.read();
            response += c;
        }
    }
    return response;
}

String ComputerLink::buildReadCommand(int address) {
    char buffer[32];
    sprintf(buffer, "\x02%02XRD%D\x03", _deviceAddress, address);
    return String(buffer);
}

String ComputerLink::buildWriteCommand(int address, int value) {
    char buffer[32];
    sprintf(buffer, "\x02%02XWD%D,%d\x03", _deviceAddress, address, value);
    return String(buffer);
}
