#include <Arduino.h>

#ifndef RELAY_H
#define RELAY_H

class Relay
{
    private:
        int _pin;
    public:
        Relay(int pin);
        void on();
        void off();
};
#endif
