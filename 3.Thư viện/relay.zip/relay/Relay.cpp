#include <Arduino.h>
#include "Relay.h"

Relay::Relay(int pin)
{
  _pin = pin;
  pinMode(_pin, OUTPUT);
  off();
}

void Relay::on()
{
  digitalWrite(_pin, LOW);
}

void Relay:: off()
{
  digitalWrite(_pin, HIGH);
}