#include "ComputerLink.h"

ComputerLink::ComputerLink(HardwareSerial &serial, uint8_t dePin)
  : _serial(serial), _dePin(dePin) {}

void ComputerLink::begin(long baudrate, uint8_t stationNo) {
  pinMode(_dePin, OUTPUT);
  digitalWrite(_dePin, LOW);
  _serial.begin(baudrate);
  _stationNo = stationNo;
}

bool ComputerLink::readD(uint16_t address, uint16_t &value) {
  char cmd[20];
  sprintf(cmd, "RD D%04u", address);
  sendCommand(String(cmd));

  String response;
  if (receiveResponse(response)) {
    value = response.substring(0, 4).toInt();
    return true;
  }
  return false;
}

bool ComputerLink::writeD(uint16_t address, uint16_t value) {
  char cmd[30];
  sprintf(cmd, "WD D%04u %04u", address, value);
  sendCommand(String(cmd));

  String response;
  return receiveResponse(response);
}

void ComputerLink::sendCommand(const String &cmd) {
  String frame = String(char(0x05)); // ENQ
  frame += String(_stationNo);
  frame += cmd;
  frame += String(char(calculateBCC(cmd)));
  frame += String('\r');

  digitalWrite(_dePin, HIGH);
  delay(2);
  _serial.print(frame);
  _serial.flush();
  delay(2);
  digitalWrite(_dePin, LOW);
}

bool ComputerLink::receiveResponse(String &response) {
  response = "";
  uint32_t start = millis();
  while (millis() - start < 1000) {
    if (_serial.available()) {
      char c = _serial.read();
      if (c == '\r') break;
      response += c;
    }
  }
  return response.length() > 0;
}

uint8_t ComputerLink::calculateBCC(const String &data) {
  uint8_t bcc = 0;
  for (size_t i = 0; i < data.length(); i++) {
    bcc ^= data[i];
  }
  return bcc;
}
