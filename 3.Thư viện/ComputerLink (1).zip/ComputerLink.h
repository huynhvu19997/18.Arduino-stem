#ifndef COMPUTERLINK_H
#define COMPUTERLINK_H

#include <Arduino.h>

class ComputerLink {
public:
  ComputerLink(HardwareSerial &serial, uint8_t dePin);
  void begin(long baudrate, uint8_t stationNo);
  bool readD(uint16_t address, uint16_t &value);
  bool writeD(uint16_t address, uint16_t value);

private:
  HardwareSerial &_serial;
  uint8_t _dePin;
  uint8_t _stationNo;

  void sendCommand(const String &cmd);
  bool receiveResponse(String &response);
  uint8_t calculateBCC(const String &data);
};

#endif
